/** Interest Cards JavaScript **/

$(document).ready(function(){
   $('.img-zoom').hover(function() {
       $(this).addClass('transition');
 
   }, function() {
       $(this).removeClass('transition');
   });
 });