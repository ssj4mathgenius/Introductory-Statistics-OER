 /** Tooltip JavaScript **/
$(function () {
  $('[data-toggle="tooltip"]').tooltip()
});